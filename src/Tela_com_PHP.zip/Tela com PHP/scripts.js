const inputElement = document.querySelector(".new-task-input");
const addTaskButton = document.querySelector(".new-task-button");

const tasksContainer = document.querySelector(".tasks-container")

const validateInput = () => inputElement.value.trim().length > 0;
//&& inputElement.value.trim().length < 21
const handleAddTask = () => {
    const inputIsValid = validateInput();

    console.log(inputIsValid);

    if (!inputIsValid) {
       return inputElement.classList.add("error");
    }

//adição de tarefas no campo de tarefas
    const taskItemContainer = document.createElement("div");
    taskItemContainer.classList.add("task-item");


    //botao de confirmação
    const confirmItem = document.createElement("button");
   
  
    

    confirmItem.addEventListener ('click', () => handleClick(confirmItem));

     const taskContent = document.createElement("p");
     taskContent.innerText = inputElement.value;
     if (inputElement.length > 20){
      document.createElement("br")
     };
    // taskContent.textContent = inputElement.value.slice(0, 20);
  

     //introduzir os elementos "i" em uma div
     const divIcons = document.createElement("div");
     divIcons.classList.add("Icons");

    //icones
     const configItem = document.createElement("i");
     configItem.classList.add("fa-solid");
     configItem.classList.add("fa-gear");

     const deleteItem = document.createElement("i");
     deleteItem.classList.add("fa-solid");
     deleteItem.classList.add("fa-trash-can");

     deleteItem.addEventListener("click", () => 
     handleDeleteClick(taskItemContainer, confirmItem)
     );

    //criação de elementos filhos
     taskItemContainer.appendChild(confirmItem);
     taskItemContainer.appendChild(taskContent);
     taskItemContainer.appendChild(divIcons);
     divIcons.appendChild(configItem);
     divIcons.appendChild(deleteItem);
    

     tasksContainer.appendChild(taskItemContainer);
     
     inputElement.value = "";
};

  //confirmação da tarefa
  const handleClick = (taskContent) => {
    const tasks = tasksContainer.childNodes;

    for (const task of tasks){
      if (task.firstChild.isSameNode(taskContent)) {
        task.firstChild.classList.toggle("completed");
      }
    }
  };

  const handleDeleteClick = (taskItemContainer,confirmItem) => {
    const tasks = tasksContainer.childNodes;

    for (const task of tasks){
      if (task.firstChild.isSameNode(confirmItem)){
        taskItemContainer.remove();
      }
    }
  };
//mudança de cor do input vermelho após digitação
const handleInputChange = () => {
    const inputIsValid = validateInput();
  
    if (inputIsValid) {
      return inputElement.classList.remove("error");
    }
  };  



addTaskButton.addEventListener("click", () => handleAddTask());



inputElement.addEventListener("change", () => handleInputChange());

document.addEventListener('keypress', function(e){
  if(e.which == 13){
     console.log('a tecla enter foi pressionada')
     handleAddTask();
    }
}, false)
