<?php 
$usuario = 'root';
$senha = '3132';
$databasse = 'login';
$host = 'localhost';

$mysqli = new mysqli($host, $usuario, $senha, $databasse);

if($mysqli->error) {
    die ("Erro ao conectar com o banco de dados: " . $mysqli->error);
}

?>