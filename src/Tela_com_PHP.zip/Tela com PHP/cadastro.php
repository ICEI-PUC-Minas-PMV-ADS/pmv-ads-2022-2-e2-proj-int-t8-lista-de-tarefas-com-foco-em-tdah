<?php 

//não tem como dar mamnutenção NAO MEXA NESSE ARQUIVO POIS NEM EU SEI O QUE TEM NELE
    include_once ("conexao.php");

if (isset($_POST['email']) && isset($_POST['senha']) && isset($_POST['nome'])){
    $email = $_POST['email'];
    $senha = $_POST['senha'];
    $nome = $_POST['nome'];

    $ja_cadastrado = "SELECT * FROM usuarios WHERE email = '$email' AND nome = '$nome' AND senha = '$senha'";
    $result_ja_cadastrado = $mysqli->query($ja_cadastrado);
   
    if($result_ja_cadastrado->num_rows > 0){
        echo "<script> alert('usuário já existe!'); </script>";
    }
    else{
        $sql = "INSERT INTO usuarios (email, senha, nome) VALUES ('$email', '$senha', '$nome')";
        $result = $mysqli->query($sql);
        echo "<script> alert('usuário cadastrado com sucesso'); </script>";
}
}


?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Cadastre-se</title>
    <link rel="stylesheet" href="tela_de_login.css">
</head>
<body>
<section class="area-login">
        <div class="login">
        <div><img src="pnglembree.png" alt="">
        </div>
  <form action="" method="post">
            <label>Nome</label>
            <input type="text" name="nome" placeholder="Digite seu Nome" autofocus>
            <label>Email</label>
            <input type="email" name="email" placeholder="Digite seu E-mail">
            <label>Senha</label>
            <input type="password" name="senha" placeholder="Digite su Senha">
            <input type="submit" value="CADASTRAR">
        </form>
        </div>
       
</body>
</html>