<?php
include_once ("conexao.php");

if (isset($_POST['email']) && isset($_POST['senha'])){
    $email = $_POST['email'];
    $senha = $_POST['senha'];
    $nome  = $_POST ['email'];

    $sql = "SELECT * FROM usuarios WHERE email = '$email' OR nome = '$nome' AND senha = '$senha'";
    $result = $mysqli->query($sql);

    if($result->num_rows > 0){

       //redirecionar para a tela de tarefas
         header("Location: tela_tarefas_lembree.html");
 }
    else{
        echo "<script> alert('Usuário ou senha incorretos!'); </script>";
    }
}

//logar com usuario ou nome

?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tela de Login</title>
    <link rel="stylesheet" href="tela_de_login.css">
</head>
<body>
    <section class="area-login">
        <div class="login">
        <div><img src="pnglembree.png" alt="">
        </div>

        <form action="" method="post">
            <label>Email</label>
            <input type="text" name="email" placeholder="Nome de Usuário" autofocus>
            <label>Senha</label>
            <input type="password" name="senha" placeholder="Senha">
            <input type="submit" value="ENTRAR">
        </form>
        <p>Não tem uma conta? <a style="text-decoration: none; color:green; font-weight: 600;" href="cadastro.php">Criar conta</a> </p>
    </div>
        </section>
        </body>
</html>